<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://#
 * @since      1.0.0
 *
 * @package    Logo_Slider
 * @subpackage Logo_Slider/admin/partials
 */


function dbi_add_logo_slider_settings() {
    add_options_page( 'Example plugin page', 'Logo Slider Settings', 'manage_options', 'dbi-example-plugin', 'dbi_render_plugin_logo_slider' );
}
add_action( 'admin_menu', 'dbi_add_logo_slider_settings' );

function dbi_render_plugin_logo_slider() {

    ?>

    <h3>Shortcode: <b>[logoslider]</b></h3>
    <form action="options.php" method="post">
        <?php 
        settings_fields( 'dbi_slider_plugin_options' );
        do_settings_sections( 'dbi_example_plugin' ); ?>
        <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Save' ); ?>" />
    </form>
    <?php
}


function dbi_register_settings() {
    register_setting( 'dbi_slider_plugin_options', 'dbi_slider_plugin_options', 'dbi_slider_plugin_options_validate' );
    add_settings_section( 'slider_settings', 'Slider Settings', 'dbi_plugin_section_text', 'dbi_example_plugin' );

    add_settings_field( 'dbi_plugin_setting_slidesToShow', 'Slides To Show', 'dbi_plugin_setting_slidesToShow', 'dbi_example_plugin', 'slider_settings' );
    add_settings_field( 'dbi_plugin_setting_slidesToScroll', 'Slides To Scroll', 'dbi_plugin_setting_slidesToScroll', 'dbi_example_plugin', 'slider_settings' );
    add_settings_field( 'dbi_plugin_setting_autoplayspeed', 'Autoplay Speed', 'dbi_plugin_setting_autoplayspeed', 'dbi_example_plugin', 'slider_settings' );
}
add_action( 'admin_init', 'dbi_register_settings' );



function dbi_plugin_section_text() {
   // echo '<p>Here you can set all the options for using the API</p>';
}

function dbi_plugin_setting_slidesToShow() {
    $options = get_option( 'dbi_slider_plugin_options' );
  if (empty($options['slidesToShow'])) {
    echo "<input id='dbi_plugin_setting_slidesToShow' name='dbi_slider_plugin_options[slidesToShow]' type='number' placeholder='3'/>";
  }else{
    echo "<input id='dbi_plugin_setting_slidesToShow' name='dbi_slider_plugin_options[slidesToShow]' type='number' value='" . esc_attr( $options['slidesToShow'] ) . "' />";
    }
  }


function dbi_plugin_setting_slidesToScroll() {
    $options = get_option( 'dbi_slider_plugin_options' );
    if (empty($options['slidesToScroll'])) {
    echo "<input id='dbi_plugin_setting_slidesToScroll' name='dbi_slider_plugin_options[slidesToScroll]' type='number' placeholder='1' />";
}else{
    echo "<input id='dbi_plugin_setting_slidesToScroll' name='dbi_slider_plugin_options[slidesToScroll]' type='number' value='" . esc_attr( $options['slidesToScroll'] ) . "' />";
}
}

function dbi_plugin_setting_autoplayspeed() {
    $options = get_option( 'dbi_slider_plugin_options');
    if (empty($options['autoplayspeed'])) {
    echo "<input id='dbi_plugin_setting_autoplayspeed' name='dbi_slider_plugin_options[autoplayspeed]' type='number' placeholder='1000' />";

    }else{

    echo "<input id='dbi_plugin_setting_autoplayspeed' name='dbi_slider_plugin_options[autoplayspeed]' type='number' value='" . esc_attr( $options['autoplayspeed'] ) . "' />";
    }
}




