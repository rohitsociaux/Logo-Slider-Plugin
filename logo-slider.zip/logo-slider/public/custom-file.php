<?php
$sliderarrayValue = get_option( 'dbi_slider_plugin_options');
$slies = $options['slidesToScroll'];
?>

<script type="text/javascript">
	 jQuery(document).ready(function(){
	 	var phpVars = <?php echo $slies; ?>
      jQuery('.customer-logos').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 500,
        arrows: true,
        dots: false,
        
          pauseOnHover: true,
          responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 3
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 2
          }
        }]
      });
    });
    
</script>