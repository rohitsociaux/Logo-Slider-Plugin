<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 */

function diwp_create_shortcode_logo_slider(){
$logostr ='';
    $sliderarrayValue = get_option( 'dbi_slider_plugin_options');
        if (empty($sliderarrayValue['slidesToShow'])) {
        $slidesToShow = 3;
        }else{
        $slidesToShow = $sliderarrayValue['slidesToShow'];
        }

        if (empty($sliderarrayValue['slidesToScroll'])) {
        $slidesToScroll = 1;
        }else{
        $slidesToScroll = $sliderarrayValue['slidesToScroll'];
        }

        if (empty($sliderarrayValue['autoplayspeed'])) {
        $autoplayspeed = 1000;
        }else{
        $autoplayspeed = $sliderarrayValue['autoplayspeed'];
        }

ob_start();
$logostr  = '<script>
   jQuery(document).ready(function(){
     var slidesToShownumber = '.$slidesToShow.'
     var slidesToScrollnumber = '.$slidesToScroll.'
     var autoplayspeedslider = '.$autoplayspeed.'
      jQuery(".customer-logos").slick({
        slidesToShow: slidesToShownumber,
        slidesToScroll: slidesToScrollnumber,
        autoplay: true,
        autoplaySpeed: autoplayspeedslider,
        arrows: true,
        dots: false,
        
          pauseOnHover: true,
          responsive: [{
          breakpoint: 768,
          settings: {
            slidesToShow: 3
          }
        }, {
          breakpoint: 520,
          settings: {
            slidesToShow: 2
          }
        }]
      });
    });
</script>';

        $args = array(
        'post_type'      => 'slider', 
        'posts_per_page' => '-1',
        'publish_status' => 'published',
        );
  
    $query = new WP_Query($args);
    if($query->have_posts()) :
        $logostr .= ' <ul class="customer-logos">';
        while($query->have_posts()) :
        $query->the_post() ;
        
        $attachment_id = get_post_thumbnail_id($query->$post_id);
        $Slimage = wp_get_attachment_image($attachment_id, 'thumbnail');
      if($Slimage){
        $logostr .= '  <li class="slide">'.$Slimage.'</li>';
      }
        endwhile;
          $logostr .= ' </ul>';
        wp_reset_postdata();
    endif;    
  ob_end_clean();
    return $logostr;            
}
  
add_shortcode( 'logoslider', 'diwp_create_shortcode_logo_slider' ); 
